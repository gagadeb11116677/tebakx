🔧 [Update] Tebak X - 19 Juni 2025: New Version Zaz Version 3.5

📅 Tanggal Rilis: 19 Juni 2025
📂 Project: Tebak X
🎯 Tujuan: Merombak total design ui/ux dan beberapa optimisasi

✅ Fitur Baru
Tema Baru ZAZ  Theme 

UI Diperbagus dan dibuat responsiv
Tampilan UI dibuat lebih profesional lebih responsiv di semua perangkat

Notifikasi Quest Selesai
Pemberitahuan otomatis ketika quest berhasil diselesaikan.

🐞 Perbaikan Bug
Skor Tidak Tersimpan Saat Menang Beruntun
Telah diperbaiki agar skor tercatat dengan benar.

Tombol 'Kembali' Tidak Responsif
Responsivitas UI tombol diperbaiki agar berfungsi di semua perangkat.

Optimisasi Pemuatan Pertanyaan
Pertanyaan kini dimuat lebih cepat, mengurangi waktu tunggu.

✅ Versi stabil dirilis


Develop BY XOBE DEVELOPMENT
